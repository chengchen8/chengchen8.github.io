import numpy as np
import matplotlib.pyplot as plt

# Load data
A = np.loadtxt('A.txt', delimiter=',')
b = np.loadtxt('b.txt')
n, d = A.shape

# parameters
learning_rate = 1
lambda_val = [0, 1e-6, 1e-3, 0.1]
x0 = np.zeros(d)
max_iterations = 300

# objective function
def logistic_regression_obj(x, A, b, lambda_val):
    z = b * np.dot(A, x)
    obj = np.log(1 + np.exp(-z)).mean() + (lambda_val / 2) * np.linalg.norm(x)**2
    return obj

# gradient
def logistic_regression_grad(x, A, b, lambda_val):
    z = -b / (np.exp(b * np.dot(A, x)) + 1)
    return np.dot(A.T, z) / n + lambda_val * x


# backtracking line search
def backtracking_line_search(x, A, b, lambda_val, grad, alpha=0.5, beta=0.8):
    t = 5
    while logistic_regression_obj(x - t * grad, A, b, lambda_val) > logistic_regression_obj(x, A, b, lambda_val) - alpha * t * np.linalg.norm(grad)**2:
        t *= beta
    return t


# Gradient descent by constant step size
def gradient_descent_constant(A, b, lambda_val, x0, learning_rate, max_iterations):
    x = x0.copy()
    obj_values = []
    grad_norms = []
    for i in range(max_iterations):
        grad = logistic_regression_grad(x, A, b, lambda_val)
        obj = logistic_regression_obj(x, A, b, lambda_val)
        grad_norm = np.linalg.norm(grad)
        obj_values.append(obj)
        grad_norms.append(grad_norm)
        x -= learning_rate * grad

    return x, obj_values, grad_norms

# Gradient descent by backtracking line search
def gradient_descent_backtracking(A, b, lambda_val, x0, learning_rate, max_iterations):
    x = x0.copy()
    obj_values = []
    grad_norms = []
    for i in range(max_iterations):
        grad = logistic_regression_grad(x, A, b, lambda_val)
        obj = logistic_regression_obj(x, A, b, lambda_val)
        grad_norm = np.linalg.norm(grad)
        obj_values.append(obj)
        grad_norms.append(grad_norm)
        t = backtracking_line_search(x, A, b, lambda_val, grad)
        x -= t * grad

    return x, obj_values, grad_norms

# plot
for lambda_val in lambda_val:
    x_bt, obj_values_bt, grad_norms_bt = gradient_descent_backtracking(A, b, lambda_val, x0, learning_rate, max_iterations)
    x_cs, obj_values_cs, grad_norms_cs = gradient_descent_constant(A, b, lambda_val, x0, learning_rate, max_iterations)
    
    iterations = np.arange(len(obj_values_bt))
    
    # function value vs iteration number
    plt.figure()
    plt.plot(iterations, obj_values_bt, label='Backtracking Line Search')
    plt.plot(iterations, obj_values_cs, label='Constant Step Size')
    plt.xlabel('Iteration Number')
    plt.ylabel('Function Value')
    plt.title(f'Lambda = {lambda_val}')
    plt.legend()
    plt.grid(True)
    plt.show()
    
    # log gradient norm vs iteration number
    plt.figure()
    plt.plot(iterations, np.log(grad_norms_bt), label='Backtracking Line Search')
    plt.plot(iterations,np.log(grad_norms_cs), label='Constant Step Size')
    plt.xlabel('Iteration Number')
    plt.ylabel('Log Gradient Norm')
    plt.title(f'Lambda = {lambda_val}')
    plt.legend()
    plt.grid(True)
    plt.show()