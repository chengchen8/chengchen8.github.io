import numpy as np
import matplotlib.pyplot as plt

# Load data
A = np.loadtxt('A.txt', delimiter=',')  # Load matrix A from file 'A.txt'
b = np.loadtxt('b.txt')  # Load vector b from file 'b.txt'
n, d = A.shape  # Get the shape of matrix A

# parameters
learning_rate = 1  # Set the learning rate for constant gradient descent, you can try range [0.1,1], [1,5].etc to find a best lr
lambda_val = [0, 1e-6, 1e-3, 0.1]  # Set the regularization parameter values
x0 = np.zeros(d)  # Initialize the solution vector x
max_iterations = 300  # Set the maximum number of iterations for gradient descent

# objective function
def logistic_regression_obj(x, A, b, lambda_val):
    z = b * np.dot(A, x)  # Calculate the product of b and Ax
    obj = np.log(1 + np.exp(-z)).mean() + (lambda_val / 2) * np.linalg.norm(x)**2  # Calculate the objective function value
    return obj

# gradient
def logistic_regression_grad(x, A, b, lambda_val):
    z = -b / (np.exp(b * np.dot(A, x)) + 1)  # Calculate the gradient of the objective function
    return np.dot(A.T, z) / n + lambda_val * x

# backtracking line search
def backtracking_line_search(x, A, b, lambda_val, grad, alpha=0.5, beta=0.8):
    t = 1  # Initialize the step size, you can try a large start
    while logistic_regression_obj(x - t * grad, A, b, lambda_val) > logistic_regression_obj(x, A, b, lambda_val) - alpha * t * np.linalg.norm(grad)**2:  # Check the Armijo condition
        t *= beta  # Decrease the step size
    return t

# Gradient descent by constant step size
def gradient_descent_constant(A, b, lambda_val, x0, learning_rate, max_iterations):
    x = x0.copy()  # Initialize the solution vector x
    obj_values = []  # Initialize the list to store the objective function values
    grad_norms = []  # Initialize the list to store the gradient norms
    for i in range(max_iterations):  # Iterate for a maximum number of times
        grad = logistic_regression_grad(x, A, b, lambda_val)  # Calculate the gradient
        obj = logistic_regression_obj(x, A, b, lambda_val)  # Calculate the objective function value
        grad_norm = np.linalg.norm(grad)  # Calculate the norm of the gradient
        obj_values.append(obj)  # Append the objective function value to the list
        grad_norms.append(grad_norm)  # Append the gradient norm to the list
        x -= learning_rate * grad  # Update the solution vector x

    return x, obj_values, grad_norms

# Gradient descent by backtracking line search
def gradient_descent_backtracking(A, b, lambda_val, x0, learning_rate, max_iterations):
    x = x0.copy()  # Initialize the solution vector x
    obj_values = []  # Initialize the list to store the objective function values
    grad_norms = []  # Initialize the list to store the gradient norms
    for i in range(max_iterations):  # Iterate for a maximum number of times
        grad = logistic_regression_grad(x, A, b, lambda_val)  # Calculate the gradient
        obj = logistic_regression_obj(x, A, b, lambda_val)  # Calculate the objective function value
        grad_norm = np.linalg.norm(grad)  # Calculate the norm of the gradient
        obj_values.append(obj)  # Append the objective function value to the list
        grad_norms.append(grad_norm)  # Append the gradient norm to the list
        t = backtracking_line_search(x, A, b, lambda_val, grad)  # Perform backtracking line search to find the step size
        x -= t * grad  # Update the solution vector x

    return x, obj_values, grad_norms

# plot
for lambda_val in lambda_val:  # Iterate over all regularization parameter values
    x_bt, obj_values_bt, grad_norms_bt = gradient_descent_backtracking(A, b, lambda_val, x0, learning_rate, max_iterations)  # Perform gradient descent with backtracking line search
    x_cs, obj_values_cs, grad_norms_cs = gradient_descent_constant(A, b, lambda_val, x0, learning_rate, max_iterations)  # Perform gradient descent with constant step size
    
    iterations = np.arange(len(obj_values_bt))  # Create an array of iteration numbers
    
    # function value vs iteration number
    plt.figure()  # Create a new figure
    plt.plot(iterations, obj_values_bt, label='Backtracking Line Search')  # Plot the objective function values for backtracking line search
    plt.plot(iterations, obj_values_cs, label='Constant Step Size')  # Plot the objective function values for constant step size
    plt.xlabel('Iteration Number')  # Set the x-axis label
    plt.ylabel('Function Value')  # Set the y-axis label
    plt.title(f'Lambda = {lambda_val}')  # Set the title of the plot
    plt.legend()  # Add a legend to the plot
    plt.grid(True)  # Add a grid to the plot
    plt.show()  # Display the plot
    
    # log gradient norm vs iteration number
    plt.figure()  # Create a new figure
    plt.plot(iterations, np.log(grad_norms_bt), label='Backtracking Line Search')  # Plot the log gradient norms for backtracking line search
    plt.plot(iterations,np.log(grad_norms_cs), label='Constant Step Size')  # Plot the log gradient norms for constant step size
    plt.xlabel('Iteration Number')  # Set the x-axis label
    plt.ylabel('Log Gradient Norm')  # Set the y-axis label
    plt.title(f'Lambda = {lambda_val}')  # Set the title of the plot
    plt.legend()  # Add a legend to the plot
    plt.grid(True)  # Add a grid to the plot
    plt.show()  # Display the plot