import numpy as np
from numpy import *
import matplotlib.pyplot as plt

A = loadtxt("A_Lasso.txt")
b = loadtxt("b_Lasso.txt")
x_opt = loadtxt("xopt.txt")

n = shape(A)[0]
d = shape(A)[1]

sigma = 0.2
lambda = 2*sigma*sqrt(log(d)/n)
iterations = 1000

error_sub1 = np.zeros(iterations)
error_sub2 = np.zeros(iterations)
error_prox = np.zeros(iterations)

# initialization
x_sub1 = np.zeros(d)
x_sub2 = np.zeros(d)
x_prox = np.zeros(d)
error_sub1[0] = np.linalg.norm(x_sub1 - x_opt)
error_sub2[0] = np.linalg.norm(x_sub2 - x_opt)
error_prox[0] = np.linalg.norm(x_prox - x_opt)

## Compute subgradient
def partial_f(x) :
	
	# g = 1/n * np.dot(np.matrix.transpose(A), np.dot(A,x) - b) + lambda*np.sign(x)
	subgrad = np.sign(x) # subgradient of L1 norm
	subgrad = subgrad.astype(np.float64)

	# if zero, draw number from [-1,1]
	subgrad[subgrad==0] = 2*np.random.rand(sum(subgrad==0))-1
	g = 1/n * np.dot(np.matrix.transpose(A), np.dot(A,x) - b) + lambda*subgrad
	return g

# Proximal gradient update
def prox(x, alpha, lambda) :
	
	# gradient step
	prox = x - alpha * 1/n * np.dot(np.matrix.transpose(A), np.dot(A,x) - b)

	# threshold
	prox[prox > alpha*lambda] = prox[prox > alpha*lambda] - alpha*lambda
	prox[prox < -alpha*lambda] = prox[prox < -alpha*lambda] + alpha*lambda
	prox[(prox > -alpha*lambda)&(prox < alpha*lambda)] = 0
	return prox

for i in np.arange(1,iterations):
	
	# subgradient constant step size
	x_sub1 = x_sub1 - 0.2 * partial_f(x_sub1)
	error_sub1[i] = np.linalg.norm(x_sub1 - x_opt)

	# subgradient decreasing step size
	x_sub2 = x_sub2 - (1/sqrt(i+1)) * partial_f(x_sub2)
	error_sub2[i] = np.linalg.norm(x_sub2 - x_opt)
	
	# proximal gradient update
	x_prox = prox(x_prox, 0.2, lambda)
	error_prox[i] = np.linalg.norm(x_prox - x_opt)

plt.figure(1); plt.clf()
plt.semilogy(np.arange(iterations), error_sub1,np.arange(iterations), error_sub2,np.arange(iterations), error_prox)
plt.legend(['SG constant alpha', 'SG decreasing alpha', 'Proximal gradient'], loc=0)
plt.xlabel('iterations')
plt.ylabel('$\|x^\ell - \hat x\|_2$')